import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:law_diary/API/api.dart';
import 'package:law_diary/API/model.dart';
import 'package:law_diary/Diary/create_diary.dart';
import 'package:law_diary/Diary/edit_diary.dart';
import 'package:law_diary/common.dart';
import 'package:law_diary/home.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:table_calendar/table_calendar.dart';

class DailyDiaryPage extends StatefulWidget {
  const DailyDiaryPage({super.key});

  @override
  State<DailyDiaryPage> createState() => _DailyDiaryPageState();
}

class _DailyDiaryPageState extends State<DailyDiaryPage> {
  List<diarylistmodel> mydiary = [];
  bool isLoading = false;
  bool hasError = false;
  String errorMessage = '';
  DateTime _selectedDate = DateTime.now();
  Map<DateTime, List<diarylistmodel>> _eventsByDate = {};

  Future<void> getdiary() async {
    setState(() {
      isLoading = true;
      hasError = false;
      errorMessage = '';
      _eventsByDate.clear();
    });

    try {
      final response = await API().getAllDiariesApi();
      final res = jsonDecode(response.body);

      if (response.statusCode == 200) {
        List diaryList = res['data'];
        final Map<DateTime, List<diarylistmodel>> updatedEvents = {};

        final updatedDiaryList = diaryList.map((diary) {
          final diaryDate = DateTime.parse(diary['appointment']);
          if (!updatedEvents.containsKey(diaryDate)) {
            updatedEvents[diaryDate] = [];
          }
          updatedEvents[diaryDate]!.add(
            diarylistmodel(
              diaryid: diary['diaryid'] ?? "",
              clientname: diary['clientname'] ?? "",
              action: diary['action'] ?? "",
              todo: diary["todo"] ?? "",
              causenum: diary["causenum"] ?? "",
              appointment: diary["appointment"] ?? "",
            ),
          );
          return diarylistmodel(
            diaryid: diary['diaryid'] ?? "",
            clientname: diary['clientname'] ?? "",
            action: diary['action'] ?? "",
            todo: diary["todo"] ?? "",
            causenum: diary["causenum"] ?? "",
            appointment: diary["appointment"] ?? "",
          );
        }).toList();
        setState(() {
          mydiary = updatedDiaryList;
          _eventsByDate = updatedEvents;
        });
      } else {
        setState(() {
          hasError = true;
          errorMessage = res['message'];
        });
      }
    } catch (e) {
      setState(() {
        hasError = true;
        errorMessage = 'An error occurred while fetching data: $e';
      });
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  List<diarylistmodel> _getEventsForDay(DateTime day) {
    return mydiary
        .where((diary) =>
            diary.appointment.isNotEmpty &&
            DateFormat('yyyy-MM-dd')
                    .format(DateTime.parse(diary.appointment)) ==
                DateFormat('yyyy-MM-dd').format(day))
        .toList();
  }

  bool isLandscape = false;

  void toggleOrientation() {
    if (isLandscape) {
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]);
    } else {
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeRight,
        DeviceOrientation.landscapeLeft,
      ]);
    }
    setState(() {
      isLandscape = !isLandscape;
    });
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    getdiary();
  }

  @override
  Widget build(BuildContext context) {
    final diariesForSelectedDate = _getEventsForDay(_selectedDate);

    return Scaffold(
      backgroundColor: maincolor,
      appBar: AppBar(
        backgroundColor: maincolor,
        elevation: 0,
        leading: BackButton(
          color: darkmain,
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const HomeScreen()),
            );
          },
        ),
        title: Text(
          'ဆောင်ရွက်ဆဲအမှုစာရင်း',
          style: GoogleFonts.poppins(
            fontSize: 17,
            color: darkmain,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(
              isLandscape ? Icons.screen_lock_portrait : Icons.rotate_right,
              color: darkmain,
            ),
            onPressed: toggleOrientation,
          ),
        ],
      ),
      body: WillPopScope(
        onWillPop: () async {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const HomeScreen()),
          );
          return false;
        },
        child: isLoading
            ? Center(
                child: SpinKitRing(size: 50, lineWidth: 5, color: maincolor),
              )
            : hasError
                ? Center(
                    child: Text(
                      errorMessage,
                      style: GoogleFonts.poppins(
                        color: Colors.red,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  )
                : SingleChildScrollView(
                    child: Column(
                      children: [
                        TableCalendar(
                          focusedDay: _selectedDate,
                          firstDay: DateTime(2000),
                          lastDay: DateTime(2100),
                          calendarFormat: CalendarFormat.week,
                          selectedDayPredicate: (day) =>
                              isSameDay(_selectedDate, day),
                          onDaySelected: (selectedDay, focusedDay) {
                            setState(() {
                              _selectedDate = selectedDay;
                            });
                          },
                          calendarStyle: CalendarStyle(
                            todayDecoration: BoxDecoration(
                              color: Colors.blueAccent,
                              shape: BoxShape.circle,
                            ),
                            selectedDecoration: BoxDecoration(
                              color: Colors.green,
                              shape: BoxShape.circle,
                            ),
                            weekendTextStyle: GoogleFonts.poppins(
                              color: Colors.redAccent,
                              fontWeight: FontWeight.bold,
                            ),
                            holidayTextStyle: GoogleFonts.poppins(
                              color: Colors.redAccent,
                              fontWeight: FontWeight.bold,
                            ),
                            outsideTextStyle: GoogleFonts.poppins(
                              color: Colors.grey,
                            ),
                            markerDecoration: BoxDecoration(
                              color: Colors.redAccent,
                              shape: BoxShape.circle,
                            ),
                          ),
                          headerStyle: HeaderStyle(
                            formatButtonVisible: false,
                            titleCentered: true,
                            leftChevronIcon:
                                Icon(Icons.arrow_left, color: Colors.black),
                            rightChevronIcon:
                                Icon(Icons.arrow_right, color: Colors.black),
                            headerMargin: const EdgeInsets.only(bottom: 10),
                            titleTextStyle: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: Colors.black87,
                            ),
                          ),
                          eventLoader: (day) {
                            return _eventsByDate[day] ?? [];
                          },
                          calendarBuilders: CalendarBuilders(
                            markerBuilder: (context, day, events) {
                              if (events.isNotEmpty) {
                                return Positioned(
                                  bottom: 4,
                                  child: Container(
                                    width: 8,
                                    height: 8,
                                    decoration: BoxDecoration(
                                      color: Colors.deepOrangeAccent,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                );
                              }
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(height: 10.0),
                        diariesForSelectedDate.isEmpty
                            ? Center(
                                child: Text(
                                  'No Data',
                                  style: GoogleFonts.poppins(
                                    fontSize: 16,
                                    color: Colors.grey,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              )
                            : SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: DataTable(
                                  headingRowColor:
                                      MaterialStateColor.resolveWith(
                                          (states) => Colors.grey.shade200),
                                  dataRowColor: MaterialStateColor.resolveWith(
                                      (states) => Colors.grey.shade50),
                                  border: TableBorder.all(
                                      color: Colors.grey.shade300, width: 1),
                                  headingTextStyle: GoogleFonts.poppins(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.blueGrey,
                                  ),
                                  dataTextStyle: GoogleFonts.poppins(
                                    fontSize: 15,
                                    color: Colors.black87,
                                  ),
                                  columnSpacing: 20,
                                  horizontalMargin: 10,
                                  columns: const [
                                    DataColumn(label: Text("Client Name")),
                                    DataColumn(label: Text("Action")),
                                    DataColumn(label: Text("ToDo")),
                                    DataColumn(label: Text("No")),
                                    DataColumn(label: Text("Appointment")),
                                    DataColumn(label: Text("Edit")),
                                    DataColumn(label: Text("Delete")),
                                  ],
                                  rows: diariesForSelectedDate.map((diary) {
                                    return DataRow(cells: [
                                      DataCell(Text(diary.clientname)),
                                      DataCell(Text(diary.action)),
                                      DataCell(Text(diary.todo)),
                                      DataCell(Text(diary.causenum)),
                                      DataCell(Text(
                                        diary.appointment.isNotEmpty
                                            ? DateFormat('yyyy-MM-dd').format(
                                                DateTime.parse(
                                                    diary.appointment))
                                            : 'No Appointment',
                                      )),
                                      DataCell(
                                        IconButton(
                                          icon: Icon(Icons.edit,
                                              color: Colors.blue),
                                          onPressed: () async {
                                            bool success = await Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        EditDiary(
                                                      editData: jsonEncode({
                                                        "diaryid":
                                                            diary.diaryid,
                                                        "clientname":
                                                            diary.clientname,
                                                        "action": diary.action,
                                                        "todo": diary.todo,
                                                        "causenum":
                                                            diary.causenum,
                                                        "appointment":
                                                            diary.appointment,
                                                      }),
                                                      diaryId: diary.diaryid,
                                                    ),
                                                  ),
                                                ) ??
                                                false;

                                            if (success) {
                                              getdiary();
                                            }
                                          },
                                        ),
                                      ),
                                      DataCell(
                                        IconButton(
                                          icon: Icon(Icons.delete,
                                              color: Colors.red),
                                          onPressed: () {
                                            showDialog(
                                              context: context,
                                              builder: (context) => AlertDialog(
                                                title: Text(
                                                    'Are you sure to Delete?'),
                                                actions: [
                                                  TextButton(
                                                      onPressed: () =>
                                                          Navigator.pop(
                                                              context),
                                                      child: Text('Cancel')),
                                                  TextButton(
                                                      onPressed: () {
                                                        deleteDiary(
                                                            diary.diaryid);
                                                        Navigator.pop(context);
                                                      },
                                                      child: Text('Delete')),
                                                ],
                                              ),
                                            );
                                          },
                                        ),
                                      ),
                                    ]);
                                  }).toList(),
                                ),
                              ),
                      ],
                    ),
                  ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: subcolor,
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const CreateDiary()),
          );
        },
        child: Icon(Icons.add, color: darkmain),
      ),
    );
  }

  deleteDiary(String id) async {
    final response = await API().deleteDiaryApi(id);
    var res = jsonDecode(response.body);

    if (response.statusCode == 200) {
      await getdiary();
      setState(() {
        _selectedDate = _selectedDate;
      });
      showToast(context, 'Diary deleted successfully.', Colors.green);
    } else if (response.statusCode == 400) {
      Navigator.pop(context);
      showToast(context, res['message'], Colors.red);
    }
  }
}
