import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:law_diary/API/api.dart';
import 'package:law_diary/Diary/daily_diary.dart';
import 'package:law_diary/common.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CreateDiary extends StatefulWidget {
  const CreateDiary({super.key});

  @override
  State<CreateDiary> createState() => _CreateDiaryState();
}

class _CreateDiaryState extends State<CreateDiary> {
  final TextEditingController _clientnameController = TextEditingController();
  final TextEditingController _actionController = TextEditingController();
  final TextEditingController _todoController = TextEditingController();
  final TextEditingController _causenumTypeController = TextEditingController();
  final TextEditingController _appointmentController = TextEditingController();

  bool isLoading = false;
  DateTime? _selectedDate;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: maincolor,
      appBar: AppBar(
        backgroundColor: maincolor,
        elevation: 0,
        leading: BackButton(
          color: darkmain,
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const DailyDiaryPage(),
              ),
            );
          },
        ),
        title: Text(
          'နေ့စဉ်မှတ်တမ်း',
          style: GoogleFonts.poppins(
            fontSize: 17,
            color: darkmain,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: WillPopScope(
        onWillPop: () async {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const DailyDiaryPage(),
            ),
          );
          return false;
        },
        child: GestureDetector(
          onTap: () {
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'အမှုနံပါတ်',
                              style: TextStyle(
                                  fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 3),
                            TextFormField(
                              controller: _causenumTypeController,
                              decoration: _buildInputDecoration(),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'အမှုသည်',
                              style: TextStyle(
                                  fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 3),
                            TextFormField(
                              controller: _clientnameController,
                              decoration: _buildInputDecoration(),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'ဆောင်ရွက်ရန်',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 5),
                  TextFormField(
                    controller: _actionController,
                    decoration: _buildInputDecoration(),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'ဆောင်ရွက်ချက်',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 5),
                  TextFormField(
                    controller: _todoController,
                    decoration: _buildInputDecoration(),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'ရုံးချိန်းရက်',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 3),
                  TextFormField(
                    decoration: _buildInputDecoration(),
                    readOnly: true,
                    onTap: () {
                      _selectDate(context);
                    },
                    controller: _appointmentController,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      persistentFooterButtons: [
        Row(
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color:subcolor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: TextButton(
                  onPressed: () {
                    if (_clientnameController.text.isEmpty) {
                      showToast(context, "အမှုသည်နာမည်ထည့်ပ!!", Colors.red);
                    } else if (_actionController.text.isEmpty) {
                      showToast(context, "ဆောင်ရွက်ရန်ထည့်ပါ", Colors.red);
                    } else if (_todoController.text.isEmpty) {
                      showToast(context, "ဆောင်ရွက်ချက်ထည့်ပါ", Colors.red);
                    } else if (_causenumTypeController.text.isEmpty) {
                      showToast(context, "အမှုနံပါတ်ထည့်ပါ", Colors.red);
                    } else if (_appointmentController.text.isEmpty) {
                      showToast(context, "ရုံးချိန်းရက်ထည့်ပါ", Colors.red);
                    } else {
                      createDiary();
                    }
                  },
                  child: isLoading
                      ? const SpinKitRing(
                          size: 23,
                          lineWidth: 3,
                          color: Colors.black,
                        )
                      : Center(
                          child: Text(
                            'Create',
                            style: GoogleFonts.poppins(
                              color: seccolor,
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

Future<void> _selectDate(BuildContext context) async {
  final DateTime? picked = await showDatePicker(
    context: context,
    initialDate: DateTime.now(),
    firstDate: DateTime(1000),
    lastDate: DateTime(2100),
  );

  if (picked != null) {
    setState(() {
      _selectedDate = picked;
      _appointmentController.text = DateFormat('yyyy-MM-dd').format(picked);
    });
  }
}

  InputDecoration _buildInputDecoration() {
    return InputDecoration(
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: Colors.grey[300]!),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Colors.blue),
      ),
    );
  }

  String diaryId = "";

  createDiary() async {
    setState(() {
      isLoading = true;
    });

    final prefs = await SharedPreferences.getInstance();
    try {
      if (_appointmentController.text.isEmpty ||
          _appointmentController.text == "Invalid date") {
        showToast(context, "ရုံးချိန်းရက်ရွေးပါ", Colors.red);
        return;
      }

      final response = await API().createDiaryApi(
        _clientnameController.text,
        _actionController.text,
        _todoController.text,
        _causenumTypeController.text,
        _appointmentController.text,
      );

      final res = jsonDecode(response.body);
      final data =
          res['data'] ?? {}; 

      if (response.statusCode == 200) {
        diaryId =
            data['diaryId'] ?? ''; 
        final token =
            res["token"] ?? '';
        await prefs.setString("token", token);

        if (context.mounted) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const DailyDiaryPage(),
            ),
          );
        }
      } else {
        showToast(context, res['message'] ?? 'မှားယွင်းမှုတခုဖြစ်ပွါးနေသည်',
            Colors.red);
      }
    } catch (e) {
      print("Error: $e");
      showToast(context, "မှတ်တမ်းဖန်တီးမှု မအောင်မြင်ပါ", Colors.red);
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }
}
